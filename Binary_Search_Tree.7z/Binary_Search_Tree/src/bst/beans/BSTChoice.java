package bst.beans;

public enum BSTChoice {
	INORDER(1),
	PREORDER(2),
	POSTORDER(3),
	INSERT(4),
	SMALLEST(5),
	LARGEST(6),
	HEIGHT(7),
	PARENT(8),
	COUNTLEAVES(9), 
	FINDLEAVES(10);
	
	private int choiceNo;
	BSTChoice (int choiceNo){
		this.choiceNo=choiceNo;
	}
	 
}
