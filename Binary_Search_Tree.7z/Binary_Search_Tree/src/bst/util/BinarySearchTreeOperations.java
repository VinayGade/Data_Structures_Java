package bst.util;

import bst.beans.Node;

public interface BinarySearchTreeOperations {
	
	Node findSmallest(Node root);
	Node findlargest(Node root);
	void insert(Node root, int data);
	Node delete(Node root, int position);
	Node findSmallestAtPosition(Node root, int position);
	Node findParent(Node root, int value);
	int findHeight(Node root);
	void inOrderTraversal(Node root);
	void preOrderTraversal(Node root);
	void postOrderTraversal(Node root);
	void levelOrderTraversal(Node root);
	boolean isLeaf(Node node);
	void findLeaves(Node root);
	int countLeaves(Node root);
	int findLevelOfNode(int data);
	
}
