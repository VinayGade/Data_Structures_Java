package bst.util;

import bst.beans.Node;

public class BinarySearchTree implements BinarySearchTreeOperations {

	public BinarySearchTree(int value) {
		Node root = new Node();
		root.setValue(value);
	}

	@Override
	public Node findSmallest(Node root) {
		Node smallest=root;
		if(smallest.getLeft() ==null){
			return smallest;
		}else{
			smallest = findSmallest(smallest.getLeft());
		}
		return smallest;
	}

	@Override
	public Node findlargest(Node root) {
		Node largest = root;
		if(largest.getRight() == null){
			return largest;
		}else{
			largest = findlargest(largest.getRight());
		}
		return largest;
	}

	@Override
	public void insert(Node root, int data) {
		Node node = new Node();
		node.setValue(data);
		if(root == null){
			root = new Node();
			root.setValue(data);
		}else{
			
		    if(data>root.getValue()){
		    	if(root.getRight() == null){
		    		root.setRight(node);
		    	}else{
		    		insert(root.getRight(), data);
		    	}
		    	
		    	
		    }
			else if(data < root.getValue()){
				if(root.getLeft() == null){
					root.setLeft(node);
				}else{
					insert(root.getLeft(),data);
				}
				
			}else{
				System.err.println("Value already exists ...CAN'T INSERT DATA.");
			}
		}
		
	}

	//challenging**
	@Override
	public Node delete(Node root, int value) {
		if(root.getValue() == value){
			
		}
		return null;
	}

	@Override
	public Node findSmallestAtPosition(Node root, int position) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Node findParent(Node root, int value) {
		
			Node parent=root;
			if(parent.getLeft() == null && parent.getRight() == null){
				parent=root;
			}
			else if(parent.getLeft().getValue() == value || parent.getRight().getValue() == value){
				return parent;
			}else if(value < parent.getLeft().getValue()){
				findParent(parent.getLeft(), value);
			}else if(value > parent.getRight().getValue()){
				findParent(parent.getRight(),value);
			}
			
		
		return parent;
	}

	@Override
	public int findHeight(Node node) {
		
		 if (node == null) 
	            return 0; 
	        if (node.getLeft() == null && node.getRight() == null) 
	            return 1; 
	        else 
	        	return Math.max(findHeight(node.getLeft()), findHeight(node.getRight()));
		
	}

	@Override
	public void inOrderTraversal(Node root) {
		if(root == null){
			return;
		}
		inOrderTraversal(root.getLeft());
		System.out.println(root.getValue());
		inOrderTraversal(root.getRight());
	}

	@Override
	public void preOrderTraversal(Node root) {
		if(root == null){
			return;
		}
		System.out.println(root.getValue());
		preOrderTraversal(root.getLeft());
		preOrderTraversal(root.getRight());
		
	}

	@Override
	public void postOrderTraversal(Node root) {
		if(root == null){
			return;
		}
		postOrderTraversal(root.getLeft());
		postOrderTraversal(root.getRight());
		System.out.println(root.getValue());
	}

	@Override
	public void levelOrderTraversal(Node root) {
		
	}

	@Override
	public boolean isLeaf(Node node) {
		return node.getLeft() == null && node.getRight() == null ;
	}

	@Override
	public void findLeaves(Node root) {
		 if(root.getLeft() == null && root.getRight() == null){
			 System.out.print(" "+root.getValue());
		 }else{
			 if(root.getLeft()!= null){
				 findLeaves(root.getLeft());
			 }else if(root.getRight()!= null){
				 findLeaves(root.getRight());
			 }
		 }
	}

	@Override
	public int countLeaves(Node node) {
		
		 if (node == null) 
	            return 0; 
	        if (node.getLeft() == null && node.getRight() == null) 
	            return 1; 
	        else
	            return countLeaves(node.getLeft()) + countLeaves(node.getRight()); 
	}

	@Override
	public int findLevelOfNode(int data) {
		// TODO Auto-generated method stub
		return 0;
	}

}
