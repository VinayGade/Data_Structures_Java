/**
 * 
 */
package bst.launcher;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import bst.beans.BSTChoice;
import bst.beans.Node;
import bst.util.BinarySearchTree;
import bst.util.BinarySearchTreeOperations;

/**
 * @author vgade
 *
 */
public class BinarySearchTreeLauncher {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Root Node data :");
		int rootData = Integer.parseInt(br.readLine());
		Node rootNode = new Node();
		rootNode.setValue(rootData);
		BinarySearchTreeOperations tree = new BinarySearchTree(rootData);
		int choice=0;
		BSTChoice bstChoices;
	
		do{
			System.out.println("********Please enter your choice******");
			System.out.println("1. Inorder traversal");
			System.out.println("2. Preorder traversal");
			System.out.println("3. postorder traversal");
			System.out.println("4. insert");
			System.out.println("5. find smallest");
			System.out.println("6. find Largest");
			System.out.println("7. height of tree");
			System.out.println("8. parent of node");
			System.out.println("9. count leaf nodes");
			System.out.println("10. find leaf nodes");
			
			choice=Integer.parseInt(br.readLine());
			
			switch(choice){
			case 1: 
				System.out.println("***1. Inorder Traversal***");
				tree.inOrderTraversal(rootNode);
				break;
			case 2: 
				System.out.println("***2. Preorder traversal***");
				tree.preOrderTraversal(rootNode);
				break;
			case 3:
				System.out.println("******3. postorder traversal******");
				tree.postOrderTraversal(rootNode);
				break;
			case 4:
				System.out.println("******4. Insert ******");
				int data = Integer.parseInt(br.readLine());
				tree.insert(rootNode, data);
				break;
			case 5:
				System.out.println("******5. find smallest ******");
				System.out.println(tree.findSmallest(rootNode).getValue());
				break;
			case 6:
				System.out.println("******6. find largest ******");
				System.out.println(tree.findlargest(rootNode).getValue());
				break;
			case 7:
				System.out.println("******7. height of tree ******");
				System.out.println(tree.findHeight(rootNode));
				break;
			case 8:
				System.out.println("******8. parent of node ******");
				int value = Integer.parseInt(br.readLine());
				System.out.println(tree.findParent(rootNode, value).getValue());
				break;
			case 9:
				System.out.println("*****9. count leaf nodes*****"+tree.countLeaves(rootNode));

				break;
			case 10:
				System.out.println("*****10. find leaf nodes*****");
				tree.findLeaves(rootNode);
				break;
			case 11:
				System.out.println("---Program terminates---");
			default :
				System.exit(0);
			}
		}while(choice<12);

	}

}
